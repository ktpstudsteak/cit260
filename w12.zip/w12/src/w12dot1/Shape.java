package w12dot1;

public abstract class Shape {

    /**
     * Returns Area
     */
    public abstract double area();

    public abstract int getId();
}
