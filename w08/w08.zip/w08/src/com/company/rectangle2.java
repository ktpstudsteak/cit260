//package com.company;
//
//public class rectangle2 {
//    private double height;
//    private double width;
//
//    //Constructors:
//
//    //default
//    rectangle() {
//        width = 1;
//        height = 1;
//    }
//}
////
////    //Allows them not to be just one? delete if it doesn't work.
//////    rectangle(double pWidth, double pHeight){
//////        width = pWidth;
//////        height = pHeight;
//////    }
////
////
//    /**
//     * the getArea method
//     * Purpose: To calculate the area of a rectangle object
//     * @return double
//     */
//    public static double getArea(){
//        return width * height;
//    }
////
//    /**
//     * the getPerimeter method
//     * Purpose: To calculate the perimeter of a rectangle object
//     * @return double
//     */
//    public static double getPerimeter(){
//        return (width * 2) + (height * 2);
//    }
////
////    /**
////     * the setHeight method
////     * Purpose: Gets the height from input and sets it as the class var height
////     * @param pHeight the height of the rectangle object being given by the user
////     */
////    public void setHeight(double pHeight) {
////        height = pHeight;
////    }
////
//    /**
//     * the getHeight method
//     * Purpose: Returns the height AFTER it has been set by setHeight()
//     * @return double
//     */
//    public static double getHeight() {
//        return height;
//    }
////
////    /**
////     * the setWidth method
////     * Purpose: Gets the width from input and sets it as the class var height
////     * @param pWidth the width of the rectangle object being given by the user
////     */
////    public void setWidth(double pWidth) {
////        width = pWidth;
////    }
////
//    /**
//     * the getWidth method
//     * Purpose: Returns the height AFTER it has been set by setWidth()
//     * @return double
//     */
//    public static double getWidth() {
//        return width;
//    }
////}
